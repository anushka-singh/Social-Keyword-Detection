# -*- coding: utf-8 -*-
import sugartensor as tf
import numpy as np
import librosa
from model import *
import data
from tqdm import tqdm
from glob import glob
import os
os.environ['TF_CPP_MIN_LOG_LEVEL']='2'
from similarity import soundex,edit_distance


traincheckpoint = '/Users/sahityasridhar/Documents/OS/keyword/wavenet/asset/train/'

WORDS = ['choose','duet','like','save','share','follow','request','add','join']

files = ['/Users/sahityasridhar/Documents/OS/keyword/dataset/mturk_ds/add/10.wav','/Users/sahityasridhar/Documents/OS/keyword/dataset/mturk_ds/share/90.wav','/Users/sahityasridhar/Documents/OS/keyword/dataset/mturk_ds/save/85.wav']

words_soundex = {}
for word in WORDS:
	words_soundex[word] = soundex(word)

def similarity(string):
	s = soundex(string)
	edits = np.array([edit_distance(string,word) for word in words_soundex])
	soundex_edits = np.array([edit_distance(words_soundex[word],soundex(string)) for word in words_soundex])
	soundex_phonetics = 0 
	if len(s)!=0:
		soundex_phonetics = np.array([0.5*(s[1:]==words_soundex[word][1:]) + 0.5*(s[0]==words_soundex[word][0]) for word in words_soundex])
	weighted = 0.2*edits + 0.4*soundex_edits + 0.4*soundex_phonetics
	target = WORDS[np.argmin(weighted)]
	return target


# set log level to debug
tf.sg_verbosity(10)


# hyper parameters
batch_size = 1     # batch size


# inputs
# vocabulary size
voca_size = data.voca_size

# mfcc feature of audio
x = tf.placeholder(dtype=tf.sg_floatx, shape=(batch_size, None, 20))

# sequence length except zero-padding
seq_len = tf.not_equal(x.sg_sum(axis=2), 0.).sg_int().sg_sum(axis=1)

# encode audio feature
logit = get_logit(x, voca_size=voca_size)

# ctc decoding
decoded, _ = tf.nn.ctc_beam_search_decoder(logit.sg_transpose(perm=[1, 0, 2]), seq_len, merge_repeated=False)

# to dense tensor
y = tf.sparse_to_dense(decoded[0].indices, decoded[0].dense_shape, decoded[0].values) + 1



with tf.Session() as sess:
	#init variables
	tf.sg_init(sess)
	# restore parameters
	saver = tf.train.Saver()
	saver.restore(sess, tf.train.latest_checkpoint(traincheckpoint))
	correct,total = 0,0
	wrong = []
	for filename in files:
		wav, _ = librosa.load(filename, mono=True, sr=16000)
		mfcc_array = np.transpose(np.expand_dims(librosa.feature.mfcc(wav, 16000), axis=0), [0, 2, 1])

		label = sess.run(y, feed_dict={x: mfcc_array})
		# print label
		predicted =  data.return_index(label).replace(" ","")
		a = similarity(predicted)
		print(a)


print('Total : ',total)
print('Correct : ',total-len(wrong))
print(wrong)